import React from 'react';

import Main from './src';

const App = () => <Main />;

export default App;
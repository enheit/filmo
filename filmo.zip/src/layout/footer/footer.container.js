import React, { Component } from 'react';
import { View, Text } from 'react-native';

// Styles
import styles from './footer.styles';

class Footer extends Component {
  render() {
    return (
      <View style={styles.footer}>
      </View>
    )
  }
}

export default Footer;
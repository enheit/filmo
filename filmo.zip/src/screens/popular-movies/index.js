export { default as PopularMoviesContainer } from './popular-movies.container';
export { default as reducer } from './popular-movies.reducer';
export { default as actionTypes } from './popular-movies.action-types';
export { default as actionCreators } from './popular-movies.actions';
export { default as sagaTasks } from './popular-movies.saga';
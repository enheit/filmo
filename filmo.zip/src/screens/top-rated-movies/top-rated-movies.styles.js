import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  topRatedMovies: {
    paddingTop: 20,
    paddingLeft: 20,
    paddingRight: 20,
  },
});

export default styles;
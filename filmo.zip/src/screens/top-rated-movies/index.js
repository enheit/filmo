export { default as TopRatedMoviesContainer } from './top-rated-movies.container';
export { default as reducer } from './top-rated-movies.reducer';
export { default as actionTypes } from './top-rated-movies.action-types';
export { default as actionCreators } from './top-rated-movies.actions';
export { default as sagaTasks } from './top-rated-movies.saga';
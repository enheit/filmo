export { default as MovieDetailsContainer } from './movie-details.container';
export { default as reducer } from './movie-details.reducer';
export { default as actionTypes } from './movie-details.action-types';
export { default as actionCreators } from './movie-details.actions';
export { default as sagaTasks } from './movie-details.saga';
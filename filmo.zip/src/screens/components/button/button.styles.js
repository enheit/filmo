import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  button: {
    borderRadius: 10,
    backgroundColor: '#fff',
    padding: 5,
  },
});

export default styles;
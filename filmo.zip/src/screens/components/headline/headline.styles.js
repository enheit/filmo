import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  headline: {
    fontWeight: 'bold',
    fontSize: 36,
  },
});

export default styles;
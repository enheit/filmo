export { default as NowPlayingMoviesContainer } from './now-playing-movies.container';
export { default as reducer } from './now-playing-movies.reducer';
export { default as actionTypes } from './now-playing-movies.action-types';
export { default as actionCreators } from './now-playing-movies.actions';
export { default as sagaTasks } from './now-playing-movies.saga';
import React, { Component } from 'react';
import { View, Text } from 'react-native';

class NotFoundContainer extends Component {
  render() {
    return (
      <View>
        <Text>Not found</Text>
      </View>
    )
  }
}

export default NotFoundContainer;
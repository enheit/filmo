const defaultState = {

};

const reducer = (state = defaultState, action) => {
  switch(action.type) {
    default:
      return state;
  }
};

export default reducer;
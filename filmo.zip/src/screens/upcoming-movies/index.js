export { default as UpcomingMoviesContainer } from './upcoming-movies.container';
export { default as reducer } from './upcoming-movies.reducer';
export { default as actionTypes } from './upcoming-movies.action-types';
export { default as actionCreators } from './upcoming-movies.actions';
export { default as sagaTasks } from './upcoming-movies.saga';
export { default as moviesAPI } from './movies.api';
export { default as configurationAPI } from './configuration.api';